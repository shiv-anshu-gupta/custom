var annotated_dup =
[
    [ "Config", "struct_config.html", "struct_config" ],
    [ "DurationConfig", "struct_duration_config.html", "struct_duration_config" ],
    [ "EqChannelData", "struct_eq_channel_data.html", "struct_eq_channel_data" ],
    [ "EqProcessor", "struct_eq_processor.html", "struct_eq_processor" ],
    [ "NpcapInterface", "struct_npcap_interface.html", "struct_npcap_interface" ],
    [ "pcap_if", "structpcap__if.html", "structpcap__if" ],
    [ "pcap_pkthdr", "structpcap__pkthdr.html", "structpcap__pkthdr" ],
    [ "pcap_send_queue", "structpcap__send__queue.html", "structpcap__send__queue" ],
    [ "StatsData", "struct_stats_data.html", "struct_stats_data" ],
    [ "SvEncoderConfig", "struct_sv_encoder_config.html", "struct_sv_encoder_config" ],
    [ "TransmitStats", "struct_transmit_stats.html", "struct_transmit_stats" ]
];