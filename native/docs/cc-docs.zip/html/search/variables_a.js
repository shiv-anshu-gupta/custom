var searchData=
[
  ['mac_0',['mac',['../struct_npcap_interface.html#a2dfb6869356ece6a340b0610bdabfa3a',1,'NpcapInterface']]],
  ['maxlen_1',['maxlen',['../structpcap__send__queue.html#ad6e74cd20e50e10a1d85d7ab36d9d614',1,'pcap_send_queue']]]
];
