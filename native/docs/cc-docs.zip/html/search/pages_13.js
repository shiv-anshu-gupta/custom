var searchData=
[
  ['raw_20socket_0',['Linux (Raw Socket)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md16',1,'']]],
  ['recommended_1',['Compile Modular Version (Recommended)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md6',1,'']]],
  ['reference_2',['API Reference',['../index.html#autotoc_md30',1,'']]],
  ['references_3',['📚 References',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md19',1,'']]]
];
