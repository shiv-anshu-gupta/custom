var searchData=
[
  ['has_5fmac_0',['has_mac',['../struct_npcap_interface.html#a051ef5dc4520d30cf40dd9c3665e626c',1,'NpcapInterface']]],
  ['headers_1',['Headers',['../index.html#autotoc_md24',1,'']]]
];
