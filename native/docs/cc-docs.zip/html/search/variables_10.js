var searchData=
[
  ['vlanid_0',['vlanID',['../struct_config.html#a10e39eb8217eddfc162c399e4d0e8ff4',1,'Config::vlanID'],['../struct_sv_encoder_config.html#a8bb728f7cee109f7c613b10197b6a791',1,'SvEncoderConfig::vlanID']]],
  ['vlanpriority_1',['vlanPriority',['../struct_config.html#a17ef73fe04d76cb3b5ba6536557b8bc0',1,'Config::vlanPriority'],['../struct_sv_encoder_config.html#ae118423f410a935963629111298fe89b',1,'SvEncoderConfig::vlanPriority']]],
  ['voltageamplitude_2',['voltageAmplitude',['../struct_config.html#af918a314f507792861be0c7518fba720',1,'Config']]]
];
