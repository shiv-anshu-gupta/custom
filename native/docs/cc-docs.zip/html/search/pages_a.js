var searchData=
[
  ['gcc_0',['Windows (MinGW/GCC)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md7',1,'']]]
];
