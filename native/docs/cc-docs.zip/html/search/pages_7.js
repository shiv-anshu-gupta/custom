var searchData=
[
  ['data_20structures_0',['Data Structures',['../index.html#autotoc_md27',1,'']]],
  ['dependencies_1',['Dependencies',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md4',1,'🔄 Module Dependencies'],['../index.html#autotoc_md26',1,'Dependencies']]]
];
