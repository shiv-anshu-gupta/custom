var indexSectionsWithContent =
{
  0: "1269abcdefghilmnopqrstuvw⚠🎯📁📊📌📐📚📡🔄🔍🔧🚀",
  1: "cdenpst",
  2: "adenrs",
  3: "bcdefgnpst",
  4: "abcdefghilmnprstvw",
  5: "dnpst",
  6: "ae",
  7: "ae",
  8: "abepsw",
  9: "16abcefistu",
  10: "1269abcdefghilmnopqrsuvw⚠🎯📁📊📌📐📚📡🔄🔍🔧🚀"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

