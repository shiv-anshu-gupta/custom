var searchData=
[
  ['data_20structures_0',['Data Structures',['../index.html#autotoc_md27',1,'']]],
  ['defaultfrequency_1',['defaultFrequency',['../struct_eq_processor.html#ac6396d60f85f753a070c2c80fb7ccf35',1,'EqProcessor']]],
  ['dependencies_2',['Dependencies',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md4',1,'🔄 Module Dependencies'],['../index.html#autotoc_md26',1,'Dependencies']]],
  ['description_3',['description',['../structpcap__if.html#a4f42d85a99b7a1e156d270f21c2ca7c0',1,'pcap_if::description'],['../struct_npcap_interface.html#a635fee0b554b92f65a472e363caaaa69',1,'NpcapInterface::description']]],
  ['dstmac_4',['dstMAC',['../struct_config.html#ad7fa5676c5c2decbf74cb5a10e637d02',1,'Config::dstMAC'],['../struct_sv_encoder_config.html#a3a08b78a878741f13be227c87ec06648',1,'SvEncoderConfig::dstMAC']]],
  ['duration_5fcheck_5felapsed_5',['duration_check_elapsed',['../duration__manager_8h.html#a60383735be2edda763aafdc5621f9c11',1,'duration_manager.h']]],
  ['duration_5fget_5fconfig_6',['duration_get_config',['../duration__manager_8h.html#a9b286463bc97cd35b3e3f31934382c09',1,'duration_manager.h']]],
  ['duration_5fget_5fcurrent_5fcycle_7',['duration_get_current_cycle',['../duration__manager_8h.html#a2c527c37a54b91a940374a713cc5ad2d',1,'duration_manager.h']]],
  ['duration_5fget_5fremaining_5fseconds_8',['duration_get_remaining_seconds',['../duration__manager_8h.html#a7379777af70cc07b1266a6466d2debf0',1,'duration_manager.h']]],
  ['duration_5fget_5ftotal_5fcycles_9',['duration_get_total_cycles',['../duration__manager_8h.html#ab6fd588519cdb5500e758f30604aa3e4',1,'duration_manager.h']]],
  ['duration_5fis_5fcomplete_10',['duration_is_complete',['../duration__manager_8h.html#a5a7bed5ae589c4a86ea01db7d5c9ee4c',1,'duration_manager.h']]],
  ['duration_5fis_5fcontinuous_11',['duration_is_continuous',['../duration__manager_8h.html#a0a8f20b0eb7109142568e1f013a6a0e6',1,'duration_manager.h']]],
  ['duration_5fmanager_2eh_12',['duration_manager.h',['../duration__manager_8h.html',1,'']]],
  ['duration_5fmark_5fcomplete_13',['duration_mark_complete',['../duration__manager_8h.html#a36148b315370498971b416cd052a8dba',1,'duration_manager.h']]],
  ['duration_5freset_14',['duration_reset',['../duration__manager_8h.html#a573abf30f252e6536620a9e70380c6ad',1,'duration_manager.h']]],
  ['duration_5fset_5fconfig_15',['duration_set_config',['../duration__manager_8h.html#a1e15fb7211d740f930eb9f01ff7c5ff0',1,'duration_manager.h']]],
  ['duration_5fstart_5fnext_5fcycle_16',['duration_start_next_cycle',['../duration__manager_8h.html#ac90334e5e1ab4ddf9df7641041e4bcaa',1,'duration_manager.h']]],
  ['durationconfig_17',['DurationConfig',['../struct_duration_config.html',1,'DurationConfig'],['../duration__manager_8h.html#ae1bd18526103e0421495a9df344ce7b4',1,'DurationConfig:&#160;duration_manager.h']]],
  ['durationseconds_18',['durationSeconds',['../struct_config.html#a24407639259b74a33277bed8ee085f1f',1,'Config::durationSeconds'],['../struct_duration_config.html#ab5155ded59c1c0a0806aeeabd57635e8',1,'DurationConfig::durationSeconds']]]
];
