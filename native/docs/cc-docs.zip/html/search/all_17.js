var searchData=
[
  ['values_20encoder_0',['SV-ASN: IEC 61850-9-2LE Sampled Values Encoder',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md0',1,'']]],
  ['version_20recommended_1',['Compile Modular Version (Recommended)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md6',1,'']]],
  ['vlanid_2',['vlanID',['../struct_config.html#a10e39eb8217eddfc162c399e4d0e8ff4',1,'Config::vlanID'],['../struct_sv_encoder_config.html#a8bb728f7cee109f7c613b10197b6a791',1,'SvEncoderConfig::vlanID']]],
  ['vlanpriority_3',['vlanPriority',['../struct_config.html#a17ef73fe04d76cb3b5ba6536557b8bc0',1,'Config::vlanPriority'],['../struct_sv_encoder_config.html#ae118423f410a935963629111298fe89b',1,'SvEncoderConfig::vlanPriority']]],
  ['voltageamplitude_4',['voltageAmplitude',['../struct_config.html#af918a314f507792861be0c7518fba720',1,'Config']]]
];
