var searchData=
[
  ['macos_0',['Linux/macOS',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md8',1,'']]],
  ['message_20structure_1',['Message Structure',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md9',1,'📊 SV Message Structure'],['../asn1__ber__encoder_8cc.html#ber_sv_structure',1,'SV Message Structure']]],
  ['mingw_20gcc_2',['Windows (MinGW/GCC)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md7',1,'']]],
  ['modular_20architecture_3',['📁 File Structure (Modular Architecture)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md3',1,'']]],
  ['modular_20version_20recommended_4',['Compile Modular Version (Recommended)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md6',1,'']]],
  ['module_5',['SV Publisher - Native C++ Module',['../index.html',1,'']]],
  ['module_20dependencies_6',['🔄 Module Dependencies',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md4',1,'']]]
];
