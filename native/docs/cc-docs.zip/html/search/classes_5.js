var searchData=
[
  ['statsdata_0',['StatsData',['../struct_stats_data.html',1,'']]],
  ['svencoderconfig_1',['SvEncoderConfig',['../struct_sv_encoder_config.html',1,'']]]
];
