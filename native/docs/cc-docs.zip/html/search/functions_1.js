var searchData=
[
  ['check_5fduration_5felapsed_0',['check_duration_elapsed',['../sv__native__refactored_8cc.html#aa18783d233bbd1ff97330bfb332b2305',1,'sv_native_refactored.cc']]]
];
