var searchData=
[
  ['flags_0',['flags',['../structpcap__if.html#a462c59a3be93b52a0762043bbab5fd3c',1,'pcap_if']]],
  ['frequency_1',['frequency',['../struct_eq_channel_data.html#a6332da14a24744f965008d31a2b9481b',1,'EqChannelData::frequency'],['../struct_config.html#ae1a585e8280c1692c874bf46f8d32f26',1,'Config::frequency']]]
];
