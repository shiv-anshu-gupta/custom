var searchData=
[
  ['1_20ber_0',['What is ASN.1 BER?',['../asn1__ber__encoder_8cc.html#ber_what',1,'']]]
];
