var searchData=
[
  ['batch_5fsize_0',['BATCH_SIZE',['../sv__native__refactored_8cc.html#a9ae2958e436c566413867028fc829ec0',1,'sv_native_refactored.cc']]]
];
