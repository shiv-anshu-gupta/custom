var searchData=
[
  ['platform_20specific_0',['📡 Network Sending (Platform-Specific)',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md15',1,'']]],
  ['publisher_20native_20c_20module_1',['SV Publisher - Native C++ Module',['../index.html',1,'']]],
  ['purpose_2',['🎯 Purpose',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md2',1,'']]]
];
