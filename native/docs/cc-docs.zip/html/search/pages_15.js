var searchData=
[
  ['usage_0',['Basic Usage',['../dir_68267d1309a1af8e8297ef4c3efbcdba.html#autotoc_md11',1,'']]]
];
